"""The public root boundary; raw graphs/checkpointers remain trusted app internals."""

import asyncio
from contextlib import asynccontextmanager, contextmanager
from uuid import UUID

from langchain_core.messages import HumanMessage, convert_to_messages
from langgraph.types import Command

from .context import current_context
from .history import KEY, validate_history
from .runtime import drain


class _AsyncUpdates:
    """A single worker owns root ContextVars and graph generator through cleanup."""

    def __init__(self, owner, inputs, config, session, prompt, kwargs):
        self.owner, self.inputs, self.config = owner, inputs, config
        self.session, self.prompt, self.kwargs = session, prompt, kwargs
        self.queue = asyncio.Queue(maxsize=1)
        self.ready = asyncio.get_running_loop().create_future()
        self.view = None
        self.closed = False
        self.producer = asyncio.create_task(self._produce())

    async def _produce(self):
        try:
            with self.owner._runtime_run(self.session, self.prompt) as view:
                self.view = view
                view.merge(await self.owner._astate(self.config))
                view.record_prompt(current_context())
                stream = self.owner._graph_stream({**self.inputs, KEY: view.value}, self.config, self.kwargs)
                self.ready.set_result(None)
                try:
                    async for update in stream:
                        await self.queue.put((True, update))
                finally:
                    view.stopping = True
                    try:
                        # Same worker as anext and root_context entry. The caller
                        # cancels this worker once; repeated caller cancellations
                        # only affect its shielded wait, not this cleanup.
                        await stream.aclose()
                    finally:
                        while view.active:
                            await drain(asyncio.gather(*list(view.active), return_exceptions=True))
        except asyncio.CancelledError:
            if not self.ready.done():
                self.ready.cancel()
            raise
        except BaseException as error:
            if not self.ready.done():
                self.ready.set_exception(error)
            else:
                await self.queue.put((False, error))
        else:
            await self.queue.put((False, StopAsyncIteration()))

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self.closed:
            raise StopAsyncIteration
        good, value = await self.queue.get()
        if good:
            return value
        raise value

    async def close(self):
        self.closed = True
        if self.view is not None:
            self.view.stopping = True
        self.producer.cancel()
        try:
            await drain(self.producer)
        except asyncio.CancelledError:
            pass


class GuardedAgent:
    __slots__ = ("__graph", "__runtime")

    def __init__(self, graph, runtime):
        self.__graph, self.__runtime = graph, runtime

    @staticmethod
    def _validate(inputs, config, kwargs):
        if isinstance(inputs, Command) or not isinstance(inputs, dict) or set(inputs) != {"messages"}:
            raise ValueError("Root input only accepts user messages; Command/resume is unsupported")
        try:
            messages = convert_to_messages(inputs["messages"])
        except Exception as error:
            raise ValueError("Invalid user messages") from error
        if not messages or any(not isinstance(m, HumanMessage) or not isinstance(m.content, str) for m in messages):
            raise ValueError("Only text user messages are accepted")
        # Strip provider/extra metadata: an external user message is plain text only.
        inputs = {"messages": [HumanMessage(content=m.content) for m in messages]}
        config = dict(config or {})
        if set(config) - {"configurable", "recursion_limit", "tags", "metadata"}:
            raise ValueError("Unsupported root run configuration")
        configurable = config.get("configurable", {})
        if not isinstance(configurable, dict) or set(configurable) != {"thread_id"}:
            raise ValueError("Only authenticated thread_id is accepted in configurable")
        try:
            session = str(UUID(configurable["thread_id"]))
        except Exception as error:
            raise ValueError("thread_id must be a stable session UUID") from error
        config["configurable"] = {"thread_id": session}
        if set(kwargs) - {"stream_mode"}:
            raise ValueError("Unsupported root execution options")
        return inputs, config, session, "\n".join(m.content for m in messages)

    def _state(self, config):
        if self.__graph.checkpointer is None:
            return {}
        state = self.__graph.get_state(config)
        if state.next or state.tasks:
            raise ValueError("Pending/interrupted execution cannot automatically resume side effects")
        return validate_history(state.values.get(KEY, {}), config["configurable"]["thread_id"])

    async def _astate(self, config):
        if self.__graph.checkpointer is None:
            return {}
        state = await self.__graph.aget_state(config)
        if state.next or state.tasks:
            raise ValueError("Pending/interrupted execution cannot automatically resume side effects")
        return validate_history(state.values.get(KEY, {}), config["configurable"]["thread_id"])

    def invoke(self, inputs, config=None, **kwargs):
        inputs, config, session, prompt = self._validate(inputs, config, kwargs)
        # Reserve root before reading a checkpoint: competing runs cannot seed stale state.
        with self.__runtime.run(session, prompt, {}) as view:
            view.merge(self._state(config))
            view.record_prompt(current_context())
            inputs = {**inputs, KEY: view.value}
            return self.__graph.invoke(inputs, config, **kwargs)

    async def ainvoke(self, inputs, config=None, **kwargs):
        inputs, config, session, prompt = self._validate(inputs, config, kwargs)
        with self.__runtime.run(session, prompt, {}) as view:
            view.merge(await self._astate(config))
            view.record_prompt(current_context())
            inputs = {**inputs, KEY: view.value}
            execution = asyncio.create_task(self.__graph.ainvoke(inputs, config, **kwargs))
            try:
                return await asyncio.shield(execution)
            except asyncio.CancelledError:
                view.stopping = True
                execution.cancel()
                try:
                    await drain(execution)
                except asyncio.CancelledError:
                    pass
                raise

    @contextmanager
    def stream(self, inputs, config=None, **kwargs):
        inputs, config, session, prompt = self._validate(inputs, config, kwargs)
        with self.__runtime.run(session, prompt, {}) as view:
            view.merge(self._state(config))
            view.record_prompt(current_context())
            inputs = {**inputs, KEY: view.value}
            stream = self.__graph.stream(inputs, config, **kwargs)
            try:
                yield stream
            finally:
                view.stopping = True
                stream.close()

    def _runtime_run(self, session, prompt):
        return self.__runtime.run(session, prompt, {})

    def _graph_stream(self, inputs, config, kwargs):
        return self.__graph.astream(inputs, config, **kwargs)

    @asynccontextmanager
    async def astream(self, inputs, config=None, **kwargs):
        inputs, config, session, prompt = self._validate(inputs, config, kwargs)
        updates = _AsyncUpdates(self, inputs, config, session, prompt, kwargs)
        try:
            await asyncio.shield(updates.ready)
            yield updates
        finally:
            await drain(updates.close())
