"""Translate policy inputs without mutating requests sent to actual tools."""

import json
import shlex
from dataclasses import dataclass, field

from deepagents.backends.local_shell import LocalShellBackend
from deepagents.middleware.filesystem import validate_path


@dataclass(frozen=True)
class Action:
    """An action expressed in the existing AgentGate policy vocabulary."""

    tool_name: str
    command: str
    cwd: str
    metadata: dict = field(default_factory=dict)


class ActionAdapter:
    """Resolve paths using exactly the backend used by the real file tools."""

    def __init__(self, backend: LocalShellBackend):
        if type(backend) is not LocalShellBackend:
            raise ValueError("Only LocalShellBackend is supported")
        self.backend = backend

    def adapt(self, name: str, args: dict) -> Action:
        """Build a complete, untruncated analysis action."""
        values = dict(args)
        metadata = {"path_mode": "virtual" if self.backend.virtual_mode else "native"}
        tool_name = {
            "execute": "bash",
            "read_file": "read",
            "write_file": "write",
            "edit_file": "edit",
            "ls": "list_dir",
            "delete": "bash",
        }.get(name, name)
        if name == "execute":
            command = values["command"]
            if not isinstance(command, str):
                raise ValueError("execute.command must be a string")
        elif name in {"read_file", "write_file", "edit_file", "delete", "ls", "glob", "grep"}:
            key = "file_path" if name in {"read_file", "write_file", "edit_file", "delete"} else "path"
            path = values.pop(key, None) or "/"
            real = str(self.backend._resolve_path(validate_path(path)))
            metadata.update(virtual_path=path, real_path=real)
            if name == "delete":
                command = "rm -- " + shlex.quote(real)
                metadata["synthetic_action"] = True
            else:
                # Paths and contents are plain values rather than JSON-escaped strings.
                parts = [shlex.quote(real)]
                for key, value in values.items():
                    parts.append(value if isinstance(value, str) else f"{key}={json.dumps(value, ensure_ascii=False)}")
                command = "\n".join(parts)
        else:
            command = json.dumps(values, ensure_ascii=False, separators=(",", ":"))
            if name in {"task", "write_todos"}:
                metadata["orchestration"] = True
        return Action(tool_name, command, str(self.backend.cwd), metadata)
