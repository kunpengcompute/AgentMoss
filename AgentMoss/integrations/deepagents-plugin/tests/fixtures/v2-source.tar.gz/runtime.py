"""Process resources and invocation-local views; no private persistent store."""

import asyncio
import logging
import re
import threading
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

from . import __version__
from .client import GateClient
from .config import GateConfig
from .context import root_context
from .history import RunHistory

logger = logging.getLogger(__name__)
_VIEW: ContextVar[RunHistory | None] = ContextVar("agentmoss_run", default=None)


async def drain(awaitable):
    """Wait through repeated cancellation; a thread-backed leaf may still be live."""
    task = asyncio.ensure_future(awaitable)
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            continue
        except BaseException:
            break
    return task.result()


class GateRuntime:
    def __init__(self, config: GateConfig, client: GateClient):
        self.config, self.client = config, client
        self.active_roots = {}
        self._guard = threading.Lock()
        self.closing = False

    @classmethod
    def load(cls, config_path: Path):
        config = GateConfig.load(config_path)
        return cls(config, GateClient(config))

    @property
    def history(self) -> RunHistory:
        view = _VIEW.get()
        if view is None:
            raise ValueError("Managed root invocation is missing")
        return view

    @contextmanager
    def run(self, session, prompt, state):
        with self._guard:
            if self.closing:
                raise RuntimeError("Runtime is closing")
            if session in self.active_roots:
                raise RuntimeError("Root session is busy")
            view = RunHistory(session, state, self.config)
            self.active_roots[session] = view
        token = _VIEW.set(view)
        try:
            with root_context(session, self.redact(prompt)):
                yield view
        finally:
            # Callers must already have drained graph/node cleanup before this boundary.
            _VIEW.reset(token)
            with self._guard:
                del self.active_roots[session]
            view.value = {}

    def redact(self, text: str) -> str:
        if self.client.token:
            text = text.replace(self.client.token, "[redacted]")
        return re.sub(r"sk-[^\s\"'<>]+", "[redacted]", text)

    def status(self):
        return {
            "enabled": self.config.enabled,
            "version": __version__,
            "agent_type": "deepagents",
            "failure_mode": "fail_closed" if self.config.fail_closed else "fail_open",
            "coverage": "main_and_synchronous_subagents",
            "layers": ["L1", "L2"],
            "history": "agent_state",
            "shell": "pwd_only",
        }

    async def aclose(self):
        with self._guard:
            self.closing = True

        # Existing requests finish deterministically; clients remain usable until drained.
        async def pending():
            while self.active_roots:
                await asyncio.sleep(0.01)

        await drain(pending())
        await self.client.aclose()
