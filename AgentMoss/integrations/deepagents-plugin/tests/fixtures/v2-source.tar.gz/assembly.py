"""Version-scoped assembly so delegation cannot omit the enforcement middleware."""

from importlib.metadata import version

from deepagents import create_deep_agent
from deepagents import graph as sdk
from deepagents.backends.local_shell import LocalShellBackend
from deepagents.middleware.filesystem import FilesystemMiddleware
from langchain.agents.middleware import AgentMiddleware

from .actions import ActionAdapter
from .compat import default_general_purpose
from .entrypoint import GuardedAgent
from .middleware import AgentMossGateMiddleware
from .runtime import GateRuntime

_VERSIONS = {
    "deepagents": "0.7.32",
    "langchain": "1.4.7",
    "langchain-core": "1.7.1",
    "langgraph": "1.2.18",
    "langgraph-prebuilt": "1.1.1",
    "httpx": "0.28.1",
}


def validate_versions() -> None:
    """Reject an unverified runtime rather than upgrading or silently losing coverage."""
    for package, expected in _VERSIONS.items():
        actual = version(package)
        if actual != expected:
            raise ValueError(f"Unsupported {package} version {actual}; expected {expected}")


def validate_profile(model):
    """Reject unverified post-check tool hooks and removal of the guard.

    0.7.32 inserts novel user middleware before the harness-profile tail. Its
    stock Skills hook cannot replace a non-None verified built-in tool, but
    arbitrary profile tool hooks/HITL edits cannot be assumed to preserve args.
    """
    resolved = sdk.resolve_model(model)
    profile = sdk._harness_profile_for_model(resolved, model if isinstance(model, str) else None)
    for entry in profile.excluded_middleware:
        if entry == "AgentMossGateMiddleware" or entry is AgentMossGateMiddleware:
            raise ValueError("Profile cannot exclude AgentMossGateMiddleware")
    if callable(profile.extra_middleware):
        raise ValueError("Profile tail middleware factories are unsupported")
    for item in profile.extra_middleware:
        if (
            type(item).wrap_tool_call is not AgentMiddleware.wrap_tool_call
            or type(item).awrap_tool_call is not AgentMiddleware.awrap_tool_call
        ):
            raise ValueError("Profile tail tool middleware is unsupported; pass it in middleware before the guard")


def validate_interrupts(options):
    if options.get("interrupt_on") or any(
        getattr(rule, "mode", None) == "interrupt" for rule in options.get("permissions", ()) or ()
    ):
        raise ValueError("Tool-editing interrupts are unsupported by the controlled root contract")


def create_guarded_agent(*, runtime: GateRuntime, model, backend: LocalShellBackend, **kwargs):
    """Create an SDK graph with guarded main and synchronous declarative subagents."""
    validate_versions()
    validate_profile(model)
    validate_interrupts(kwargs)
    adapter = ActionAdapter(backend)

    def guarded(middlewares, role):
        for middleware in middlewares:
            if isinstance(middleware, FilesystemMiddleware) or middleware.name == "FilesystemMiddleware":
                if not isinstance(middleware, FilesystemMiddleware) or middleware.backend is not backend:
                    raise ValueError("FilesystemMiddleware backend must match the guarded backend")
        return [m for m in middlewares if m.name != "AgentMossGateMiddleware"] + [
            AgentMossGateMiddleware(runtime, adapter, role)
        ]

    specs = list(kwargs.pop("subagents", None) or [])
    for spec in specs:
        if not isinstance(spec, dict) or "runnable" in spec or "graph_id" in spec:
            raise ValueError("Unsupported compiled or asynchronous subagent")
        validate_profile(spec.get("model", model))
        validate_interrupts(spec)
    if not any(spec.get("name") == "general-purpose" for spec in specs):
        default = default_general_purpose(model, backend, kwargs)
        if default is not None:
            specs.append(default)
    subagents = [{**spec, "middleware": guarded(spec.get("middleware", ()), spec["name"])} for spec in specs]
    main_middleware = guarded(kwargs.pop("middleware", ()), "main")
    graph = create_deep_agent(model=model, backend=backend, middleware=main_middleware, subagents=subagents, **kwargs)
    return GuardedAgent(graph, runtime)
