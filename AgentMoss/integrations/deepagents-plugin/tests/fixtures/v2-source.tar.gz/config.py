"""Validated configuration; credentials remain in a separate protected file."""

import json
import math
from dataclasses import dataclass, fields
from pathlib import Path
from urllib.parse import urlsplit


@dataclass(frozen=True)
class GateConfig:
    """Runtime policy and payload bounds for one application process."""

    api_token_file: Path
    enabled: bool = True
    gate_url: str = "http://127.0.0.1:9100"
    timeout_seconds: float = 5.0
    fail_closed: bool = False
    request_bytes: int = 256 * 1024
    history_actions: int = 200
    history_turns: int = 20
    history_bytes: int = 32 * 1024

    def __post_init__(self) -> None:
        if type(self.enabled) is not bool or type(self.fail_closed) is not bool:
            raise ValueError("enabled and fail_closed must be booleans")
        url = urlsplit(self.gate_url)
        if (
            url.scheme not in {"http", "https"}
            or not url.hostname
            or url.username
            or url.password
            or url.query
            or url.fragment
        ):
            raise ValueError("gate_url must be an HTTP(S) base URL without credentials")
        if (
            isinstance(self.timeout_seconds, bool)
            or not isinstance(self.timeout_seconds, (int, float))
            or not math.isfinite(self.timeout_seconds)
            or self.timeout_seconds <= 0
        ):
            raise ValueError("timeout_seconds must be positive and finite")
        for name in ("request_bytes", "history_actions", "history_turns", "history_bytes"):
            if type(getattr(self, name)) is not int or getattr(self, name) <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if not isinstance(self.api_token_file, Path):
            raise ValueError("api_token_file must be a Path")
        if self.enabled and not self.api_token_file.read_text().strip():
            raise ValueError("API token file is empty")

    @classmethod
    def load(cls, path: Path) -> "GateConfig":
        """Load explicit configuration; never silently disable enforcement."""
        raw = json.loads(path.read_text())
        if not isinstance(raw, dict) or "api_token_file" not in raw:
            raise ValueError("api_token_file is required")
        unknown = raw.keys() - {field.name for field in fields(cls)}
        if unknown:
            raise ValueError(f"Unknown configuration keys: {sorted(unknown)}")
        token_path = Path(raw.pop("api_token_file"))
        if not token_path.is_absolute():
            token_path = path.parent / token_path
        return cls(api_token_file=token_path, **raw)
