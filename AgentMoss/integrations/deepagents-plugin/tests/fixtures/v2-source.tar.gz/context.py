"""Stable root identity and task-local delegation lineage."""

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, replace
from uuid import UUID, uuid4


@dataclass(frozen=True)
class CallContext:
    """Identity inherited by tools, never inferred from model-generated text."""

    root_session_id: str
    prompt: str
    turn_id: str
    scope: str = "main"
    parent_call_id: str = ""
    task: str = ""

    @property
    def gate_session_id(self) -> str:
        return "deepagents:" + self.root_session_id


_CONTEXT: ContextVar[CallContext | None] = ContextVar("agentmoss_context", default=None)


def current_context() -> CallContext:
    """Require explicit application context rather than grouping unknown sessions."""
    context = _CONTEXT.get()
    if context is None:
        raise ValueError("AgentMoss root session context is missing")
    return context


@contextmanager
def root_context(session_id: str, prompt: str):
    """Bind a persisted browser UUID during a complete graph invocation."""
    session = str(UUID(session_id))
    if not isinstance(prompt, str):
        raise ValueError("Root prompt must be text")
    token = _CONTEXT.set(CallContext(session, prompt, str(uuid4())))
    try:
        yield current_context()
    finally:
        _CONTEXT.reset(token)


@contextmanager
def child_context(call_id: str, role: str, task: str):
    """Bind one delegation across its tool handler without changing root identity."""
    parent = current_context()
    token = _CONTEXT.set(
        replace(parent, scope=parent.scope + "/" + call_id + ":" + role, parent_call_id=call_id, task=task)
    )
    try:
        yield current_context()
    finally:
        _CONTEXT.reset(token)
