"""The pinned SDK's automatic GP policy, preserved before explicit gate injection."""

from deepagents import graph as sdk


def default_general_purpose(model, backend, kwargs):
    """Mirror 0.7.32's automatic GP stack including existing slot restrictions."""
    resolved = sdk.resolve_model(model)
    profile = sdk._harness_profile_for_model(resolved, model if isinstance(model, str) else None)
    gp_profile = profile.general_purpose_subagent or sdk.GeneralPurposeSubagentProfile()
    if gp_profile.enabled is False:
        return None
    main_middleware = kwargs.get("middleware", ())
    skills = kwargs.get("skills")
    if skills is None:
        skills = sdk._passed_skills_sources(main_middleware)
    stack = [
        sdk.FilesystemMiddleware(
            backend=backend,
            custom_tool_descriptions=profile.tool_description_overrides,
            permissions=kwargs.get("permissions"),
        ),
        sdk.create_summarization_middleware(resolved, backend),
        sdk.PatchToolCallsMiddleware(),
    ]
    stack.extend(profile.materialize_extra_middleware())
    if skills is not None:
        stack.append(sdk.SkillsMiddleware(backend=backend, sources=skills))
    sdk.append_prompt_caching_middleware(stack)
    names = {middleware.name for middleware in stack}
    inherited = [middleware for middleware in main_middleware if middleware.name in names]
    stack = sdk._apply_excluded_middleware(stack, profile)
    stack = sdk._apply_custom_middleware(stack, inherited)
    stack = sdk._apply_excluded_middleware(stack, profile)
    if profile.excluded_tools:
        stack.append(sdk._ToolExclusionMiddleware(excluded=profile.excluded_tools))
    spec = {
        **sdk.GENERAL_PURPOSE_SUBAGENT,
        "model": model,
        "tools": sdk._apply_tool_description_overrides(kwargs.get("tools"), profile.tool_description_overrides) or [],
        "middleware": stack,
    }
    if gp_profile.description is not None:
        spec["description"] = gp_profile.description
    if gp_profile.system_prompt is not None:
        prompt = gp_profile.system_prompt
        if profile.system_prompt_suffix is not None:
            prompt += "\n\n" + profile.system_prompt_suffix
        spec["system_prompt"] = prompt
    else:
        spec["system_prompt"] = sdk._apply_profile_prompt(profile, sdk.GENERAL_PURPOSE_SUBAGENT["system_prompt"])
    return spec
