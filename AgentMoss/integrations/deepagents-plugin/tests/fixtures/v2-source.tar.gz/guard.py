"""Conservative structured effects and exact, versioned read authorization.

Not an OS sandbox: the workspace must not have hostile concurrent writers.
"""

import stat
from dataclasses import dataclass
from pathlib import Path

from deepagents.backends.local_shell import LocalShellBackend
from deepagents.middleware.filesystem import validate_path


@dataclass(frozen=True)
class FilePlan:
    name: str
    args: dict
    paths: tuple[str, ...] = ()
    fingerprints: tuple[tuple | None, ...] = ()
    mutation: bool = False


def fingerprint(path: Path) -> tuple:
    value = path.stat()
    if not stat.S_ISREG(value.st_mode):
        raise ValueError("Only regular files have read evidence")
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


class FileGuard:
    def __init__(self, backend: LocalShellBackend):
        if type(backend) is not LocalShellBackend:
            raise ValueError("Only LocalShellBackend is supported")
        self.backend = backend

    def resolve(self, value: str) -> Path:
        validated = validate_path(value)
        lexical = (self.backend.cwd / validated.lstrip("/")) if self.backend.virtual_mode else Path(validated)
        if not lexical.is_absolute():
            lexical = self.backend.cwd / lexical
        # resolve() would erase a dangling link and misclassify it as a new file.
        for component in [lexical, *lexical.parents]:
            if component.is_symlink() and not component.exists():
                raise ValueError("Dangling link is not a new file")
        return self.backend._resolve_path(validated).resolve(strict=False)

    def prepare(self, name: str, args: dict, reads: list[dict]) -> FilePlan:
        if name == "execute":
            if args.get("command") != "pwd":
                raise ValueError("Unknown Shell targets: only exact pwd is supported")
            if self.backend._env.get("ENV") or self.backend._env.get("BASH_ENV"):
                raise ValueError("Shell initialization environment is not fixed")
            return FilePlan(name, dict(args))
        if name in {"task", "write_todos", "ls", "glob", "grep"}:
            return FilePlan(name, dict(args))
        if name not in {"read_file", "write_file", "edit_file", "delete"}:
            raise ValueError("Unknown tool execution contract")
        if name == "delete" and self.backend._resolve_path(validate_path(args["file_path"])).is_symlink():
            # Native absolute delete unlinks the link object, while virtual and
            # relative paths are resolved by this backend. Do not authorize a
            # different object using the referent's read evidence.
            raise ValueError("Symlink-object deletion is unsupported")
        path = self.resolve(args["file_path"])
        try:
            current = fingerprint(path)
        except FileNotFoundError:
            if name != "write_file":
                raise ValueError("File does not exist") from None
            # Require a concrete parent; do not infer inaccessible/missing paths.
            if not path.parent.stat() or not path.parent.is_dir():
                raise ValueError("New file parent is unknown") from None
            current = None
        mutation = name != "read_file"
        if (
            mutation
            and current is not None
            and not any(
                read.get("canonical_path") == str(path) and tuple(read.get("fingerprint", ())) == current
                for read in reads
            )
        ):
            raise ValueError("Exact target requires a current verified read_file")
        return FilePlan(name, dict(args), (str(path),), (current,), mutation)

    def recheck(self, plan: FilePlan, reads: list[dict]) -> None:
        fresh = self.prepare(plan.name, plan.args, reads)
        if fresh != plan:
            raise ValueError("Target changed during analysis")

    def proof(self, plan: FilePlan, args: dict) -> dict:
        if plan.name != "read_file" or not plan.paths or args.get("limit", 100) <= 0:
            raise ValueError("Not a completed read window")
        self.recheck(plan, [])
        current = fingerprint(Path(plan.paths[0]))
        if current != plan.fingerprints[0]:
            raise ValueError("File changed while reading")
        return {
            "canonical_path": plan.paths[0],
            "fingerprint": list(current),
            "offset": max(0, args.get("offset", 0)),
            "limit": args.get("limit", 100),
        }
