"""Private AgentGate integration for the pinned DeepAgents laboratory runtime."""

__version__ = "0.2.0"


# Public imports stay lazy: config/actions can be used without assembling a graph.
def __getattr__(name):
    if name == "create_guarded_agent":
        from .assembly import create_guarded_agent

        return create_guarded_agent
    if name == "GateRuntime":
        from .runtime import GateRuntime

        return GateRuntime
    raise AttributeError(name)
