"""Bounded reducer-backed state. No plugin-owned persistent storage."""

import asyncio
import json
import shlex
import threading
from contextlib import asynccontextmanager, contextmanager
from typing import Annotated

from langchain.agents.middleware import AgentState

KEY = "agentmoss_history"
EVENT_FIELDS = {
    "root_session_id",
    "scope",
    "parent_call_id",
    "tool_call_id",
    "turn_id",
    "original_name",
    "action_type",
    "action_detail",
    "cwd",
    "status",
    "source",
    "decision",
    "seq",
    "verified_reads",
}
STATUSES = {"attempted", "denied", "executed_success", "executed_error", "unknown"}


def bounded(text: str, limit: int) -> str:
    return text.encode()[:limit].decode(errors="ignore")


def event_key(event):
    return (event["root_session_id"], event["scope"], event["tool_call_id"])


def empty_history(root=""):
    return {"schema": 2, "root": root, "events": [], "turns": [], "truncated": False}


def validate_history(value, root):
    if not value:
        return empty_history(root)
    if (
        not isinstance(value, dict)
        or set(value) != {"schema", "root", "events", "turns", "truncated"}
        or value["schema"] != 2
        or value["root"] != root
    ):
        raise ValueError("Incompatible or cross-root plugin state")
    if not isinstance(value["events"], list) or not isinstance(value["turns"], list):
        raise ValueError("Invalid plugin state lists")
    for event in value["events"]:
        if (
            not isinstance(event, dict)
            or set(event) - EVENT_FIELDS
            or event.get("root_session_id") != root
            or event.get("status") not in STATUSES
            or type(event.get("seq")) is not int
        ):
            raise ValueError("Invalid plugin event")
        event_key(event)
        for read in event.get("verified_reads", []):
            if (
                event["status"] != "executed_success"
                or event["original_name"] != "read_file"
                or set(read) != {"canonical_path", "fingerprint", "offset", "limit", "source_key"}
                or read["source_key"] != list(event_key(event))
                or not isinstance(read["canonical_path"], str)
                or not read["canonical_path"].startswith("/")
                or len(read["fingerprint"]) != 5
                or not all(type(v) is int for v in read["fingerprint"])
            ):
                raise ValueError("Invalid read evidence source")
    for turn in value["turns"]:
        if (
            not isinstance(turn, dict)
            or set(turn) != {"id", "text"}
            or not all(isinstance(v, str) for v in turn.values())
        ):
            raise ValueError("Invalid user turn")
    return value


def prune(value, actions=200, turns=20, budget=32768):
    result = {**value, "events": list(value["events"]), "turns": list(value["turns"])}
    if len(result["events"]) > actions or len(result["turns"]) > turns:
        result["truncated"] = True
    result["events"] = result["events"][-actions:]
    result["turns"] = result["turns"][-turns:]
    valid = {t["id"] for t in result["turns"]}
    result["events"] = [e for e in result["events"] if e["turn_id"] in valid]
    while len(json.dumps(result, ensure_ascii=False).encode()) > budget and (result["events"] or result["turns"]):
        result["truncated"] = True
        (result["events"] if result["events"] else result["turns"]).pop(0)
    return result


def merge_history(old, delta):
    if not old and not delta:
        return {}
    root = (old or delta)["root"]
    old, delta = validate_history(old, root), validate_history(delta, root)
    events = {}
    for event in old["events"] + delta["events"]:
        key = event_key(event)
        if key not in events or event["seq"] >= events[key]["seq"]:
            events[key] = event
    turns = {turn["id"]: turn for turn in old["turns"] + delta["turns"]}
    return prune(
        {
            "schema": 2,
            "root": root,
            "events": sorted(events.values(), key=lambda e: e["seq"]),
            "turns": list(turns.values()),
            "truncated": old["truncated"] or delta["truncated"],
        }
    )


class AgentMossState(AgentState):
    agentmoss_history: Annotated[dict, merge_history]


class RunHistory:
    """One root invocation's shared view, seeded only from trusted graph state."""

    def __init__(self, root, value, config):
        self.value = validate_history(value, root)
        self.config = config
        self.seq = max((e["seq"] for e in self.value["events"]), default=0)
        self.lock = threading.Lock()
        self.stopping = False
        self.active = set()

    def merge(self, value):
        self.value = self.trim(merge_history(self.value, value))
        self.seq = max(self.seq, max((e["seq"] for e in self.value["events"]), default=0))

    def trim(self, value):
        return prune(
            value,
            min(200, self.config.history_actions),
            min(20, self.config.history_turns),
            min(32768, self.config.history_bytes),
        )

    def record_prompt(self, context):
        self.merge(
            empty_history(context.root_session_id)
            | {"turns": [{"id": context.turn_id, "text": bounded(context.prompt, 16000)}]}
        )

    def begin(self, context, call_id, action, original_name):
        if self.stopping:
            raise ValueError("Root invocation is closing")
        self.record_prompt(context)
        key = (context.root_session_id, context.scope, call_id)
        if not call_id or any(event_key(e) == key for e in self.value["events"]):
            raise ValueError("Recorded tool call cannot be replayed")
        self.seq += 1
        event = {
            "root_session_id": context.root_session_id,
            "scope": context.scope,
            "parent_call_id": context.parent_call_id,
            "tool_call_id": call_id,
            "turn_id": context.turn_id,
            "original_name": original_name,
            "action_type": action.tool_name,
            "action_detail": bounded(action.command, 2048),
            "cwd": action.cwd,
            "status": "attempted",
            "source": "",
            "decision": "",
            "seq": self.seq,
            "verified_reads": [],
        }
        self.merge(empty_history(context.root_session_id) | {"events": [event]})
        return event

    def finish(self, event, status, *, decision="", source="", reads=()):
        self.seq += 1
        event.update(status=status, decision=decision, source=source, seq=self.seq, verified_reads=list(reads))
        self.merge(empty_history(event["root_session_id"]) | {"events": [dict(event)]})

    def reads(self):
        return [r for e in self.value["events"] if e["status"] == "executed_success" for r in e["verified_reads"]]

    def invalidate(self, paths):
        for event in list(self.value["events"]):
            if any(r["canonical_path"] in paths for r in event["verified_reads"]):
                self.finish(
                    dict(event),
                    event["status"],
                    decision=event["decision"],
                    source=event["source"],
                    reads=[r for r in event["verified_reads"] if r["canonical_path"] not in paths],
                )

    def snapshot(self, targets=()):
        rows = [(e, r) for e in self.value["events"] for r in e["verified_reads"] if r["canonical_path"] in targets]

        def actions(turn=None):
            return [
                {"action_type": "read", "action_detail": shlex.quote(r["canonical_path"])}
                for e, r in rows
                if turn is None or e["turn_id"] == turn
            ]

        result = {
            "action_history": actions(),
            "prompt_history": [{"text": t["text"], "actions": actions(t["id"])} for t in self.value["turns"]],
            "history_truncated": self.value["truncated"],
        }
        while (
            len(json.dumps(result, ensure_ascii=False).encode()) > self.config.history_bytes
            and result["prompt_history"]
        ):
            result["prompt_history"].pop(0)
            result["history_truncated"] = True
        return result

    @contextmanager
    def leaf_lock(self):
        with self.lock:
            yield

    @asynccontextmanager
    async def async_leaf_lock(self):
        acquired = False
        try:
            while not acquired:
                acquired = self.lock.acquire(blocking=False)
                if not acquired:
                    await asyncio.sleep(0.005)
            yield
        finally:
            if acquired:
                self.lock.release()
