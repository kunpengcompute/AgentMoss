"""Local exact authorization, Gate analysis, actual execution, then state delta."""

import asyncio
import inspect
import json
import logging
import platform
import re
from contextlib import nullcontext
from dataclasses import replace

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, ToolMessage
from langgraph.types import Command

from . import __version__
from .client import GateUnavailable
from .context import child_context, current_context
from .guard import FileGuard
from .history import KEY, AgentMossState, event_key
from .runtime import drain

logger = logging.getLogger(__name__)
_FILE_TOOLS = {"read_file", "write_file", "edit_file", "delete", "ls", "glob", "grep", "execute"}


class AgentMossGateMiddleware(AgentMiddleware):
    state_schema = AgentMossState

    def __init__(self, runtime, adapter, role="main"):
        self.runtime, self.adapter, self.role = runtime, adapter, role
        self.guard = FileGuard(adapter.backend)

    def _error(self, request, reason):
        return ToolMessage(
            content=self.runtime.redact("AgentMoss: " + reason)[:2000],
            tool_call_id=request.tool_call["id"],
            name=request.tool_call["name"],
            status="error",
        )

    def _contract(self, request):
        name, tool = request.tool_call["name"], request.tool
        if name in _FILE_TOOLS:
            func = getattr(tool, "func", None)
            expected = f"FilesystemMiddleware._create_{name}_tool.<locals>.sync_{name}"
            if (
                not inspect.isfunction(func)
                or func.__module__ != "deepagents.middleware.filesystem"
                or func.__qualname__ != expected
            ):
                raise ValueError("Unverified filesystem tool implementation")
            owner = inspect.getclosurevars(func).nonlocals.get("self")
            if owner is None or owner.backend is not self.adapter.backend:
                raise ValueError("Tool backend differs from guarded backend")
        elif name == "task":
            if not getattr(tool, "func", None) or tool.func.__module__ != "deepagents.middleware.subagents":
                raise ValueError("Unverified delegation tool")
        elif name == "write_todos":
            if not getattr(tool, "func", None) or tool.func.__module__ != "langchain.agents.middleware.todo":
                raise ValueError("Unverified todo tool")
        else:
            raise ValueError("Unknown tool execution contract")

    def _result(self, result):
        view = self.runtime.history
        if isinstance(result, Command):
            if not isinstance(result.update, dict):
                raise ValueError("Trusted tool Command update must be a dictionary")
            if KEY in result.update:
                view.merge(result.update[KEY])
            return replace(result, update={**result.update, KEY: view.value})
        return Command(update={"messages": [result], KEY: view.value})

    def _prepare(self, request):
        ctx, view = current_context(), self.runtime.history
        if request.state.get(KEY):
            view.merge(request.state[KEY])
        name, args = request.tool_call["name"], request.tool_call["args"]
        action = self.adapter.adapt(name, args)
        # Diagnostics retain paths/names, never copied file bodies or ordinary outputs.
        detail = action.metadata.get("real_path", "pwd" if name == "execute" and args.get("command") == "pwd" else name)
        detail = self.runtime.redact(detail)
        event = view.begin(ctx, request.tool_call["id"], replace(action, command=detail), name)
        try:
            self._contract(request)
            plan = self.guard.prepare(name, args, view.reads())
            snapshot = view.snapshot(plan.paths if plan.mutation else ())
            messages = request.state.get("messages", [])
            reason = next(
                (
                    m.content
                    for m in reversed(messages)
                    if isinstance(m, AIMessage) and isinstance(m.content, str) and m.content
                ),
                "",
            )
            payload = {
                "agent_type": "deepagents",
                "agent_version": "deepagents-plugin-" + __version__,
                "session_id": ctx.gate_session_id,
                "cwd": action.cwd,
                "tool_name": action.tool_name,
                "command": action.command,
                "description": reason,
                "user_prompt": ctx.prompt,
                "action_history": snapshot["action_history"],
                "prompt_history": snapshot["prompt_history"],
                "metadata": {
                    **action.metadata,
                    "hostname": platform.node(),
                    "os_type": platform.system().lower(),
                    "source": "deepagents-plugin",
                    "original_tool_name": name,
                    "tool_call_id": request.tool_call["id"],
                    "scope": ctx.scope,
                    "parent_call_id": ctx.parent_call_id,
                    "agent_role": self.role,
                    "delegated_task": ctx.task,
                    "history_truncated": snapshot["history_truncated"],
                },
            }
            if len(json.dumps(payload, ensure_ascii=False).encode()) > self.runtime.config.request_bytes:
                raise ValueError("Analysis request exceeds configured limit; action was not truncated")
            return event, plan, payload
        except Exception as error:
            view.finish(event, "denied", decision="Deny", source="plugin")
            return self._result(self._error(request, str(error)))

    def _fault(self, error):
        closed = self.runtime.config.fail_closed
        logger.warning("AgentGate unavailable (%s); %s", type(error).__name__, "fail_closed" if closed else "bypass")
        return {
            "decision": "Deny" if closed else "Bypass",
            "reason": "AgentGate unavailable",
            "source": "fail_closed" if closed else "bypass",
        }

    def _check(self, request, event, plan, verdict):
        view = self.runtime.history
        if verdict["decision"] == "Deny":
            view.finish(event, "denied", decision="Deny", source=verdict.get("source", "agent_moss"))
            return self._result(self._error(request, str(verdict.get("reason", "Rejected"))))
        try:
            # Gate-time target replacement and final-request mutation are both rejected.
            if request.tool_call["args"] != plan.args:
                raise ValueError("Tool arguments changed during analysis")
            self._contract(request)
            self.guard.recheck(plan, view.reads())
        except Exception as error:
            view.finish(event, "denied", decision="Deny", source="plugin")
            return self._result(self._error(request, str(error)))
        return None

    def _record(self, request, event, plan, result, verdict):
        view = self.runtime.history
        if isinstance(result, Command):
            if not isinstance(result.update, dict):
                raise ValueError("Unverified Command state representation")
            if KEY in result.update:
                view.merge(result.update[KEY])
            messages = result.update.get("messages", [])
            message = next((m for m in reversed(messages) if isinstance(m, ToolMessage)), None)
        else:
            message = result
        status, reads = "unknown", []
        if isinstance(message, ToolMessage):
            if message.status == "error":
                status = "executed_error"
            elif request.tool_call["name"] == "execute":
                code = message.artifact.get("exit_code") if isinstance(message.artifact, dict) else None
                status = "unknown" if code is None else "executed_success" if code == 0 else "executed_error"
            else:
                status = "executed_success"
            # The pinned built-in text tool emits a leading numeric window header.
            # Error text, empty reminders and unknown/media shapes earn no evidence.
            window = (
                re.match(
                    r"(?:\[Requested offset[^\n]*\]\n)?@@ lines (\d+)-(\d+)(?: of \d+)?"
                    r"(?: \| [^\n]*)? @@\n([\s\S]+)$",
                    message.content,
                )
                if isinstance(message.content, str)
                else None
            )
            if (
                request.tool_call["name"] == "read_file"
                and status == "executed_success"
                and window
                and int(window[2]) >= int(window[1]) >= 1
                and window[3].strip()
                and plan.fingerprints[0][2] > 0
            ):
                try:
                    proof = self.guard.proof(plan, request.tool_call["args"])
                    proof.update(offset=int(window[1]) - 1, limit=int(window[2]) - int(window[1]) + 1)
                    proof["source_key"] = list(event_key(event))
                    reads = [proof]
                except (ValueError, OSError):
                    pass
        if plan.mutation:
            # Even failed/unknown writes may have had effects.
            view.invalidate(plan.paths)
        view.finish(
            event, status, decision=verdict["decision"], source=verdict.get("source", "agent_moss"), reads=reads
        )
        return self._result(result)

    @staticmethod
    def _delegation(request):
        if request.tool_call["name"] != "task":
            return nullcontext()
        args = request.tool_call["args"]
        return child_context(
            request.tool_call["id"], str(args.get("subagent_type", "general-purpose")), str(args.get("description", ""))
        )

    async def _execute(self, request, handler):
        if request.tool_call["name"] == "task":
            return await handler(request)
        view = self.runtime.history
        execution = asyncio.ensure_future(handler(request))
        view.active.add(execution)
        try:
            return await asyncio.shield(execution)
        except asyncio.CancelledError:
            try:
                await drain(execution)
            except BaseException:
                pass
            raise
        finally:
            view.active.discard(execution)

    def wrap_tool_call(self, request, handler):
        if not self.runtime.config.enabled:
            return handler(request)
        try:
            view = self.runtime.history
            lock = nullcontext() if request.tool_call["name"] == "task" else view.leaf_lock()
            with lock:
                prepared = self._prepare(request)
                if isinstance(prepared, Command):
                    return prepared
                event, plan, payload = prepared
                try:
                    verdict = self.runtime.client.analyze(payload)
                except GateUnavailable as error:
                    verdict = self._fault(error)
                if (denial := self._check(request, event, plan, verdict)) is not None:
                    return denial
                try:
                    with self._delegation(request):
                        result = handler(request)
                except BaseException:
                    view.invalidate(plan.paths if plan.mutation else ())
                    view.finish(event, "unknown", source="exception")
                    raise
                return self._record(request, event, plan, result, verdict)
        except Exception as error:
            return self._error(request, "local integration error: " + str(error))

    async def awrap_tool_call(self, request, handler):
        if not self.runtime.config.enabled:
            return await handler(request)
        try:
            view = self.runtime.history
            lock = nullcontext() if request.tool_call["name"] == "task" else view.async_leaf_lock()
            async with lock:
                prepared = self._prepare(request)
                if isinstance(prepared, Command):
                    return prepared
                event, plan, payload = prepared
                try:
                    verdict = await self.runtime.client.aanalyze(payload)
                except GateUnavailable as error:
                    verdict = self._fault(error)
                except asyncio.CancelledError:
                    view.finish(event, "unknown", source="cancelled_analysis")
                    raise
                if (denial := self._check(request, event, plan, verdict)) is not None:
                    return denial
                try:
                    with self._delegation(request):
                        result = await self._execute(request, handler)
                except BaseException:
                    view.invalidate(plan.paths if plan.mutation else ())
                    view.finish(event, "unknown", source="cancelled_or_exception")
                    raise
                return self._record(request, event, plan, result, verdict)
        except Exception as error:
            return self._error(request, "local integration error: " + str(error))
